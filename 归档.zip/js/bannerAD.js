//创建广告窗体
const bannerAD = document.createElement("div");
const icon = document.createElement("img");
const title = document.createElement("div");
const subtitle = document.createElement("div");
const jumpButton = document.createElement("hw-button");
const closeButton = document.createElement("div");


bannerAD.classList.add("bannerAD");
title.classList.add("bannerAD-title");
subtitle.classList.add("bannerAD-subtitle");
closeButton.classList.add("bannerAD-closeButton");

closeButton.innerHTML = "X";
title.innerHTML = "网站由___________提供计算支持"
icon.setAttribute("src",'	https://app.rainyun.com/img/logo.d193755d.png')

bannerAD.appendChild(icon);
bannerAD.appendChild(title);
bannerAD.appendChild(subtitle);
bannerAD.appendChild(closeButton);
document.body.appendChild(bannerAD);

setTimeout(function(){
    bannerAD.style.top = 0;
},10)

closeButton.addEventListener("click",function(){
    bannerAD.style.top = "-60px";
})