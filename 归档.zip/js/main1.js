document.querySelector("body").addEventListener("dblclick", function () {
    event.preventDefault();
})

var isLogin = false;

CheckTokenIsLive();

//Token检查是否过期
function CheckTokenIsLive(){
    axios({
        method:'post',
        url: "https://api2.hisuperwan.com:8080/checkTokenIsLive",
        data: {
            "token": localStorage.getItem("token"),
            "username":localStorage.getItem("username")
        }
    }).then(result => {
        if(result.data === false) {
            localStorage.removeItem("token");
            localStorage.removeItem("username");
            location.href = "/login.html?callback=" + location.href + "&msg=您的登录状态已过期，请重新登录";
        }else{
            isLogin = true;
        }
    })
}

function CheckEmail(){
    //检查url是否有邮箱参数
    var url = new URL(location.href);
    if(url.searchParams.get("email") === "binding"){
        return;
    }else{
        if(isLogin){
            axios({
                method:'post',
                url: "https://api2.hisuperwan.com:8080/user/getInfo",
                data: {
                    "token": localStorage.getItem("token"),
                    "username":localStorage.getItem("username")
                }
            }).then(result => {
                if(result.data.data.email === null){
                    location.href = "/bindEmail.html?" + "callback=" + location.href + "&token=" + localStorage.getItem("token") + "&username=" + localStorage.getItem("username") + "&email=binding";
                }
            })
        }
    }
}

setInterval(CheckEmail,1000);

setInterval(CheckTokenIsLive,1000);